1. 轉了大部分的tri model至jason格式
2. 這些model的vertex均有color
3. 需要注意一下model的大小問題
4. 由於這些model沒有texture和texcoord屬性，所以提供另外一份index.html供大家參考
5. 如果使用model過程中有其他問題，請聯繫助教